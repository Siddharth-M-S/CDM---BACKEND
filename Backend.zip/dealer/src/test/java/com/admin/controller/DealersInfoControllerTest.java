package com.admin.controller;

import com.admin.entity.DealerInfoEntity;

import com.admin.service.DealerService;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;

import org.mockito.Mock;

import org.mockito.junit.jupiter.MockitoExtension;


import java.util.Arrays;

import java.util.List;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)

class DealersInfoControllerTest {

    @Mock

    private DealerService dealerService;

    @InjectMocks

    private DealersInfoController dealersInfoController;

    private DealerInfoEntity dealerInfo;

    @BeforeEach

    public void setUp() {

        dealerInfo = new DealerInfoEntity();

        dealerInfo.setId(1L);

        dealerInfo.setUsername("Test Dealer");

    }

    @Test

    void testViewDealer() {

        List<DealerInfoEntity> dealerList = Arrays.asList(dealerInfo);

        when(dealerService.getAllDealers()).thenReturn(dealerList);

        List<DealerInfoEntity> result = dealersInfoController.viewDealer();

        assertNotNull(result);

        assertEquals(1, result.size());

        assertEquals(dealerInfo.getUsername(), result.get(0).getUsername());

    }

    @Test

    void testAddDealer() {

        when(dealerService.saveDealer(dealerInfo)).thenReturn("Dealer added successfully");

        String result = String.valueOf(dealersInfoController.addDealer(dealerInfo));

        assertEquals("Dealer added successfully", result);

    }

    @Test

    void testDealerById() {

        Long dealerId = 1L;

        when(dealerService.dealerById(dealerId)).thenReturn(Optional.of(dealerInfo));

        Optional<DealerInfoEntity> result = dealersInfoController.dealerById(dealerId);


        assertTrue(result.isPresent());

        assertEquals(dealerInfo.getId(), result.get().getId());

        assertEquals(dealerInfo.getUsername(), result.get().getUsername());

    }

    @Test

    void testDeleteDealer() {

        Long dealerId = 1L;

        when(dealerService.deleteDealer(dealerId)).thenReturn("Dealer deleted successfully");


        String result = dealersInfoController.deleteDealer(dealerId);


        assertEquals("Dealer deleted successfully", result);

    }

    @Test

    void testUpdateDealer() {

        Long dealerId = 1L;

        DealerInfoEntity updatedDealer = new DealerInfoEntity();

        updatedDealer.setUsername("Updated Dealer");

        when(dealerService.updateDealer(dealerId, updatedDealer)).thenReturn(updatedDealer);

        DealerInfoEntity result = dealersInfoController.updateDealer(dealerId, updatedDealer);

        assertNotNull(result);

        assertEquals(updatedDealer.getUsername(), result.getUsername());

    }

    @Test

    void testLoginSuccess() {

        String result = dealersInfoController.loginSuccess();

        assertEquals("login Page", result);

    }

}

