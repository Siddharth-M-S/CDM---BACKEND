//package com.admin.controller;
//
//import com.admin.dto.OrderDTO;
//import com.admin.service.OrderService;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import java.util.Arrays;
//import java.util.List;
//
//import static org.mockito.Mockito.*;
//import static org.junit.jupiter.api.Assertions.*;
//
//class OrderControllerTest {
//
//    @InjectMocks
//    private OrderController orderController;
//
//    @Mock
//    private OrderService orderService;
//
//    private OrderDTO orderDTO;
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.openMocks(this);
//
//        orderDTO = new OrderDTO();
//        orderDTO.setOrderId(1);
//        orderDTO.setDealerId(1);
//    }
//
//    @Test
//    void testGetOrder() {
//        when(orderService.getOrderWithItems(1)).thenReturn(orderDTO);
//
//        ResponseEntity<OrderDTO> response = orderController.getOrder(1);
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertNotNull(response.getBody());
//        assertEquals(1, response.getBody().getOrderId());
//    }
//
//    @Test
//    void testGetOrderNotFound() {
//        when(orderService.getOrderWithItems(1)).thenReturn(null);
//
//        ResponseEntity<OrderDTO> response = orderController.getOrder(1);
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertNull(response.getBody());
//    }
//
//    @Test
//    void testGetOrdersByDealer() {
//        OrderDTO orderDTO2 = new OrderDTO();
//        orderDTO2.setOrderId(2);
//        orderDTO2.setDealerId(1);
//
//        List<OrderDTO> orders = Arrays.asList(orderDTO, orderDTO2);
//        when(orderService.getOrdersByDealerId(1L)).thenReturn(orders);
//
//        List<OrderDTO> response = orderController.getOrdersByDealer(1L);
//
//        assertNotNull(response);
//        assertEquals(2, response.size());
//        assertEquals(1, response.get(0).getDealerId());
//    }
//
//    @Test
//    void testGetOrdersByDealerNotFound() {
//        when(orderService.getOrdersByDealerId(2L)).thenReturn(Arrays.asList());
//
//        List<OrderDTO> response = orderController.getOrdersByDealer(2L);
//
//        assertNotNull(response);
//        assertTrue(response.isEmpty());
//    }
//}
