package com.admin.controller;

import com.admin.entity.Car;
import com.admin.service.CarServices;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class CarEntityControllerTest {

    @InjectMocks
    private CarController carController;

    @Mock
    private CarServices carServices;

    private Car car;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        car = new Car();
        car.setId(1);
        car.setName("Tesla");
        car.setDescription("Model S");
    }

    @Test
    void testGetAllCars() {
        List<Car> cars = Arrays.asList(car);
        when(carServices.getAllCars()).thenReturn(cars);

        ResponseEntity<List<Car>> response = carController.getAllCars();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        assertEquals("Tesla", response.getBody().get(0).getName());
    }

    @Test
    void testGetCarByIdFound() {
        when(carServices.getCarById(1)).thenReturn(car);

        ResponseEntity<Car> response = carController.getCarById(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Tesla", response.getBody().getName());
    }

    @Test
    void testGetCarByIdNotFound() {
        when(carServices.getCarById(1)).thenReturn(null);

        ResponseEntity<Car> response = carController.getCarById(1);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void testGetAllCarsByPage() {
        List<Car> cars = Arrays.asList(car);
        Page<Car> carPage = new PageImpl<>(cars, PageRequest.of(0, 1), 1);
        when(carServices.getAllCarsByPage(0, 1)).thenReturn(carPage);

        ResponseEntity<Page<Car>> response = carController.getAllCarsByPage(0, 1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().getContent().size());
    }

    @Test
    void testAddCar() {
        when(carServices.addCar(any(Car.class))).thenReturn(car);

        ResponseEntity<Car> response = carController.addCar(car);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Tesla", response.getBody().getName());
    }

    @Test
    void testAddCarInternalServerError() {
        when(carServices.addCar(any(Car.class))).thenThrow(new RuntimeException("Error"));

        ResponseEntity<Car> response = carController.addCar(car);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    void testDeleteCarFound() {
        when(carServices.getCarById(1)).thenReturn(car);
        doNothing().when(carServices).deleteCar(1);

        ResponseEntity<String> response = carController.deleteProduct(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Deleted", response.getBody());
    }

    @Test
    void testDeleteCarNotFound() {
        when(carServices.getCarById(1)).thenReturn(null);

        ResponseEntity<String> response = carController.deleteProduct(1);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Car not found", response.getBody());
    }
}
