package com.admin;

import com.admin.entity.Car;
import com.admin.repository.CarRepository;
import com.admin.service.CarServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class CarEntityServiceImplTest {

    @Mock
    private CarRepository repo;

    @InjectMocks
    private CarServiceImpl service;

    private Car car=null;
    private List<Car> carList;

    @BeforeEach
    public void mockCar(){

        carList=new ArrayList<>();
        car=new Car();
        car.setId(1);
        car.setAvailable("1");
        car.setBrand("nissan");
        car.setName("Magnite");
        car.setCategory("suv");
        car.setDescription("Good Car for Climbing");
        car.setPrice(BigDecimal.valueOf(20000000));
        carList.add(car);
    }

    @Test
    void getAllCars() {

        when(repo.findAll()).thenReturn(carList);

        List<Car> result=service.getAllCars();

        assertEquals(carList,result);
    }

    @Test
    void getCarById() {
        when(repo.findById(1)).thenReturn(Optional.of(car));

        Car result = service.getCarById(1);

        assertEquals(car, result);    }


    @Test
    void getAllCarsByPage() {
        carList = Collections.singletonList(car);
        Page<Car> carPage = new PageImpl<>(carList);

        Pageable pageable = PageRequest.of(0, 10);
        when(repo.findAll(pageable)).thenReturn(carPage);

        Page<Car> result = service.getAllCarsByPage(0, 10);

        assertEquals(carPage, result);
        assertEquals(1, result.getTotalElements());
        assertEquals(carList, result.getContent());
    }

    @Test
    void addCar() {

        when(repo.save(car)).thenReturn(car);
        Car savedCar=service.addCar(car);

        assertEquals(car.getId(),savedCar.getId());
    }

    @Test
    void deleteCar() {
        service.deleteCar(1);

        verify(repo, times(1)).deleteById(1);
    }
    @Test
    void addCar_failure() {
        when(repo.save(car)).thenThrow(new RuntimeException("Database error"));

        assertThrows(RuntimeException.class, () -> service.addCar(car));
    }


}