package com.admin.service.order_service;

import com.admin.entity.*;
import com.admin.exception.CustomException;
import com.admin.repository.*;
import com.admin.service.order_service.OrderServiceImpl;
import com.admin.service.order_service.OrderServices;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OrderServiceImplTest {

    @Mock
    private CarRepository carRepo;

    @Mock
    private OrdersRepository ordersRepository;

    @Mock
    private OrderItemsRepository orderItemsRepository;

    @Mock
    private DealerInfoRepository dealerInfoRepository;

    @Mock
    private CartRepository cartRepository;

    @Mock
    private CartItemsRepository cartItemsRepository;

    @InjectMocks
    private OrderServiceImpl orderService;

    // Test case for adding a car to cart
    @Test
    public void testAddCarToCart_Success() {
        Long dealerId = 1L;
        Long carId = 1L;
        Integer quantity = 2;

        Car car = new Car();
        car.setId(Math.toIntExact(carId));
        car.setPrice(BigDecimal.valueOf(10000));

        DealerInfoEntity dealerInfoEntity = new DealerInfoEntity();
        dealerInfoEntity.setId(dealerId);

        CartEntity cart = new CartEntity();
        cart.setDealerInfoEntity(dealerInfoEntity);
        cart.setItems(new ArrayList<>());

        CartItemEntity cartItem = new CartItemEntity();
        cartItem.setCar(car);
        cartItem.setQuantity(quantity);
        cartItem.setCart(cart);

        when(carRepo.findById(Math.toIntExact(carId))).thenReturn(Optional.of(car));
        when(dealerInfoRepository.findById(dealerId)).thenReturn(Optional.of(dealerInfoEntity));
        when(cartRepository.findByDealerInfoEntityId(dealerId)).thenReturn(Optional.of(cart));

        CartEntity savedCart = new CartEntity();
        savedCart.setDealerInfoEntity(dealerInfoEntity);
        savedCart.setItems(Collections.singletonList(cartItem));
        when(cartRepository.save(any(CartEntity.class))).thenReturn(savedCart);

        // Call method
        CartEntity result = orderService.addCarToCart(dealerId, carId, quantity);

        // Assertions
        assertNotNull(result);
        assertEquals(1, result.getItems().size());
        assertEquals(carId, result.getItems().get(0).getCar().getId());
        assertEquals(quantity, result.getItems().get(0).getQuantity());
    }

    // Test case for adding car to cart (when cart does not exist)
    @Test
    public void testAddCarToCart_CreateNewCart() {
        Long dealerId = 1L;
        Long carId = 1L;
        Integer quantity = 2;

        // Mocking car entity
        Car car = new Car();
        car.setId(Math.toIntExact(carId));
        car.setPrice(BigDecimal.valueOf(10000));

        // Mocking dealer entity
        DealerInfoEntity dealerInfoEntity = new DealerInfoEntity();
        dealerInfoEntity.setId(dealerId);

        // Setting up mock behavior for repositories
        when(carRepo.findById(Math.toIntExact(carId))).thenReturn(Optional.of(car));
        when(dealerInfoRepository.findById(dealerId)).thenReturn(Optional.of(dealerInfoEntity));
        when(cartRepository.findByDealerInfoEntityId(dealerId)).thenReturn(Optional.empty());

        // Creating a new cart entity
        CartEntity newCart = new CartEntity();
        newCart.setDealerInfoEntity(dealerInfoEntity);
        newCart.setItems(new ArrayList<>());

        // Creating cart item and setting values
        CartItemEntity cartItem = new CartItemEntity();
        cartItem.setCar(car);
        cartItem.setQuantity(quantity);
        cartItem.setCart(newCart);

        // Mocking the save behavior for cart repository
        when(cartRepository.save(any(CartEntity.class))).thenReturn(newCart);

        // Invoking the method under test
        CartEntity result = orderService.addCarToCart(dealerId, carId, quantity);

        // Verifying results
        assertNotNull(result);
        assertEquals(1, result.getItems().size(), "Cart should have one item");
    }

    // Test case for placing an order

//    @Test
//    public void testPlaceOrder_Success() {
//        // Setup mock behavior
//        when(cartRepository.findById(1L)).thenReturn(Optional.of(mockCart));
//        when(cartRepository.findByDealerInfoEntityId(1L)).thenReturn(Optional.of(mockCart));
//        when(orderItemsRepository.save(any(OrderItemEntity.class))).thenReturn(new OrderItemEntity());
//        when(ordersRepository.save(any(OrderEntity.class))).thenReturn(new OrderEntity());
//        doNothing().when(cartRepository).delete(any(CartEntity.class));
//
//        // Execute the method under test
//        OrderEntity result = orderService.placeOrder(1L, 1L);
//
//        // Assert that the result is not null
//        assertNotNull(result);
//
//        // Verify that the total price was correctly calculated
//        assertEquals(new BigDecimal("5000.00"), result.getTotalPrice());
//
//        // Verify interactions with the mocked repositories
//        verify(cartRepository, times(1)).findById(1L);
//        verify(cartRepository, times(1)).delete(mockCart);
//        verify(orderItemsRepository, times(1)).save(any(OrderItemEntity.class));
//        verify(ordersRepository, times(1)).save(any(OrderEntity.class));
//    }


    // Test case for placing an order when cart does not belong to dealer
    @Test
    @Transactional
    public void testPlaceOrder_Fail_CartNotBelongsToDealer() {
        Long dealerId = 1L;
        Long cartId = 1L;
        String address="sjoaje";

        CartEntity cart = new CartEntity();
        cart.setId(cartId);
        DealerInfoEntity dealerInfoEntity = new DealerInfoEntity();
        dealerInfoEntity.setId(2L); // Different dealer ID
        cart.setDealerInfoEntity(dealerInfoEntity);

        when(cartRepository.findById(cartId)).thenReturn(Optional.of(cart));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            orderService.placeOrder(dealerId, cartId,address);
        });

        assertEquals("Cart does not belong to the dealer", exception.getMessage());
    }

    // Test case for removing a cart item
    @Test
    @Transactional
    public void testRemoveCartItem_Success() {
        Long dealerId = 1L;
        Long cartItemId = 1L;

        CartEntity cart = new CartEntity();
        DealerInfoEntity dealerInfoEntity = new DealerInfoEntity();
        dealerInfoEntity.setId(dealerId);
        cart.setDealerInfoEntity(dealerInfoEntity);
        cart.setItems(new ArrayList<>());

        CartItemEntity cartItem = new CartItemEntity();
        cartItem.setId(cartItemId);
        cartItem.setCar(new Car());
        cartItem.setQuantity(1);
        cart.getItems().add(cartItem);

        when(cartRepository.findByDealerInfoEntityId(dealerId)).thenReturn(Optional.of(cart));
        when(cartItemsRepository.findById(cartItemId)).thenReturn(Optional.of(cartItem));

        Optional<CartEntity> result = orderService.removeCartItem(dealerId, cartItemId);

        assertTrue(result.isPresent());
        assertTrue(result.get().getItems().isEmpty());
    }

    // Test case for removing a cart item (when cart item is not found)
    @Test
    @Transactional
    public void testRemoveCartItem_Fail_CartItemNotFound() {
        Long dealerId = 1L;
        Long cartItemId = 999L; // Non-existent cart item

        CartEntity cart = new CartEntity();
        DealerInfoEntity dealerInfoEntity = new DealerInfoEntity();
        dealerInfoEntity.setId(dealerId);
        cart.setDealerInfoEntity(dealerInfoEntity);

        when(cartRepository.findByDealerInfoEntityId(dealerId)).thenReturn(Optional.of(cart));
        when(cartItemsRepository.findById(cartItemId)).thenReturn(Optional.empty());

        Optional<CartEntity> result = orderService.removeCartItem(dealerId, cartItemId);

        assertFalse(result.isPresent());
    }

    // Test case for soft deleting an order
    @Test
    public void testSoftDeleteOrder_Success() {
        Long orderId = 1L;

        OrderEntity order = new OrderEntity();
        order.setId(orderId);
        order.setDeleted(false);

        when(ordersRepository.findById(orderId)).thenReturn(Optional.of(order));
        when(ordersRepository.save(order)).thenReturn(order);

        boolean result = orderService.softDeleteOrderById(orderId);

        assertTrue(result);
        assertTrue(order.isDeleted());
    }

    @Test
    public void testSoftDeleteOrder_Fail_OrderNotFound() {
        Long orderId = 999L; // Non-existent order ID

        when(ordersRepository.findById(orderId)).thenReturn(Optional.empty());

        boolean result = orderService.softDeleteOrderById(orderId);

        assertFalse(result);
    }

    // Test case for getting max car sales
    @Test
    public void testGetMaxCarSales() {
        List<Map<String, Object>> result = new ArrayList<>();
        Map<String, Object> carSales = new HashMap<>();
        carSales.put("car", "CarModel1");
        carSales.put("sales", 100);
        result.add(carSales);

        when(ordersRepository.getMaxCarSales()).thenReturn(result);

        List<Map<String, Object>> carSalesList = orderService.getMaxCarSales();

        assertNotNull(carSalesList);
        assertFalse(carSalesList.isEmpty());
        assertEquals("CarModel1", carSalesList.get(0).get("car"));
    }
}
