package com.admin.service;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class PasswordServiceTest {

    private PasswordService passwordService;

    @Before
    public void setUp() {
        passwordService = new PasswordService();
    }

    @Test
    public void testGenerateRandomPassword_Length() {
        // Act: Generate the random password
        String password = passwordService.generateRandomPassword();

        // Assert: Verify that the password has the expected length
        assertEquals(12, password.length());
    }

    @Test
    public void testGenerateRandomPassword_ValidCharacters() {
        // Act: Generate the random password
        String password = passwordService.generateRandomPassword();

        // Assert: Verify that the password contains only valid characters
        String validCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_-+=<>?";

        // Loop through each character in the generated password and verify that it is part of the valid characters
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            assertTrue(validCharacters.contains(String.valueOf(c)));
        }
    }

    @Test
    public void testGenerateRandomPassword_DifferentPasswords() {
        // Act: Generate two random passwords
        String password1 = passwordService.generateRandomPassword();
        String password2 = passwordService.generateRandomPassword();

        // Assert: Verify that the two generated passwords are not the same
        assertNotEquals(password1, password2);
    }
}
