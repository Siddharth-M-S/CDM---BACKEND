package com.admin.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.admin.entity.DealerInfoEntity;
import com.admin.repository.DealerInfoRepository;
import com.admin.service.PasswordService;
import com.admin.service.EmailService;
import com.admin.exception.CustomException;
import com.admin.service.LoginService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

@ExtendWith(MockitoExtension.class) // This extension allows the use of Mockito in JUnit 5
public class LoginServiceTest {

    @Mock
    private DealerInfoRepository dealerInfoRepository;

    @Mock
    private PasswordService passwordService;

    @Mock
    private EmailService emailService;

    @InjectMocks
    private LoginService loginService;

    private DealerInfoEntity dealerInfoEntity;

    @BeforeEach
    public void setUp() {
        // Setting up a mock DealerInfoEntity for testing
        dealerInfoEntity = new DealerInfoEntity();
        dealerInfoEntity.setId(1L);
        dealerInfoEntity.setUsername("dealerUser");
        dealerInfoEntity.setEmail("dealer@example.com");
        dealerInfoEntity.setPhoneNumber(Long.valueOf("123456789"));
        dealerInfoEntity.setPassword("password123"); // Password should be encoded when saved
    }

    // Test case for saving dealer successfully
    @Test
    public void testSaveDealer_Success() {
        // Arrange: Mocking the behavior of dependencies
        when(dealerInfoRepository.save(any(DealerInfoEntity.class))).thenReturn(dealerInfoEntity);
        when(passwordService.generateRandomPassword()).thenReturn("randomPassword");
        when(emailService.sendLoginCredentials(anyString(), anyString(), anyString(), anyLong())).thenReturn(true);

        // Act: Call the method
        String result = loginService.saveDealer(dealerInfoEntity);

        // Assert: Verify the expected results
        assertEquals("Dealer added successfully", result);

        // Verify that the necessary repository and methods are called
        verify(dealerInfoRepository, times(1)).save(any(DealerInfoEntity.class));
        verify(emailService, times(1)).sendLoginCredentials(anyString(), anyString(), anyString(), anyLong());
    }

    // Test case for failure when email is not sent while saving the dealer
    @Test
    public void testSaveDealer_FailureEmailNotSent() {
        // Arrange: Mocking the behavior of dependencies
        when(dealerInfoRepository.save(any(DealerInfoEntity.class))).thenReturn(dealerInfoEntity);
        when(passwordService.generateRandomPassword()).thenReturn("randomPassword");
        when(emailService.sendLoginCredentials(anyString(), anyString(), anyString(), anyLong())).thenReturn(false);

        // Act: Call the method
        String result = loginService.saveDealer(dealerInfoEntity);

        // Assert: Verify the expected result when email sending fails
        assertEquals("Dealer Not added Successfully", result);
    }

    // Test case for validating dealer login successfully
    @Test
    public void testValidateDealer_Success() {
        // Arrange: Mocking the behavior of dependencies
        dealerInfoEntity.setPassword("password123");  // Ensure correct password is set
        when(dealerInfoRepository.findById(anyLong())).thenReturn(Optional.of(dealerInfoEntity));

        // Act: Call the method
        String result = loginService.validateDealer(dealerInfoEntity);

        // Assert: Verify the expected result
        assertEquals("Login Successful", result);
    }

    // Test case for failed login with incorrect password
    @Test
    public void testValidateDealer_Failed_Login() {
        // Arrange: Mocking the behavior of dependencies
        when(dealerInfoRepository.findById(anyLong())).thenReturn(Optional.of(dealerInfoEntity));
        dealerInfoEntity.setPassword("wrongPassword");

        // Act: Call the method
        String result = loginService.validateDealer(dealerInfoEntity);

        // Assert: Verify the expected result when login fails
        assertEquals("Login Credential Failed", result);
    }

    // Test case for when dealer is not found
    @Test
    public void testValidateDealer_DealerNotFound() {
        // Arrange: Mocking the behavior of dependencies
        when(dealerInfoRepository.findById(anyLong())).thenReturn(Optional.empty());

        // Act: Call the method
        String result = loginService.validateDealer(dealerInfoEntity);

        // Assert: Verify the expected result when dealer is not found
        assertEquals("There is no such dealer", result);
    }

    // Test case for deleting dealer successfully
    @Test
    public void testDeleteDealer_Success() {
        // Arrange: Mocking the behavior of dependencies
        doNothing().when(dealerInfoRepository).deleteById(anyLong());

        // Act: Call the method
        String result = loginService.deleteDealer(1L);

        // Assert: Verify the expected result
        assertEquals("Dealer deleted successfully", result);

        // Verify delete method is called
        verify(dealerInfoRepository, times(1)).deleteById(anyLong());
    }

    // Test case for failure while deleting dealer
    @Test
    public void testDeleteDealer_Failure() {
        // Arrange: Mocking the behavior of dependencies
        doThrow(new RuntimeException("Error")).when(dealerInfoRepository).deleteById(anyLong());

        // Act & Assert: Expect an exception
        assertThrows(CustomException.class, () -> {
            loginService.deleteDealer(1L);
        });
    }

    // Test case for successful password reset
    @Test
    public void testForgotPassword_Success() {
        // Arrange: Mocking the behavior of dependencies
        when(dealerInfoRepository.findById(anyLong())).thenReturn(Optional.of(dealerInfoEntity));

        // Act: Call the method
        String result = loginService.forgotPassword("password123", 1L, "newPassword123");

        // Assert: Verify the expected result
        assertEquals("Renamed Succesfully", result);
    }

    // Test case for when dealer is not found during password reset
    @Test
    public void testForgotPassword_DealerNotFound() {
        // Arrange: Mocking the behavior of dependencies
        when(dealerInfoRepository.findById(anyLong())).thenReturn(Optional.empty());

        // Act: Call the method
        String result = loginService.forgotPassword("password123", 1L, "newPassword123");

        // Assert: Verify the expected result
        assertEquals("Dealer Not Found", result);
    }

    // Test case for password mismatch during password reset
    @Test
    public void testForgotPassword_PasswordMismatch() {
        // Arrange: Mocking the behavior of dependencies
        when(dealerInfoRepository.findById(anyLong())).thenReturn(Optional.of(dealerInfoEntity));

        // Act: Call the method with a wrong password
        String result = loginService.forgotPassword("wrongPassword", 1L, "newPassword123");

        // Assert: Verify the expected result
        assertEquals("Not verified correctly", result);
    }

    // Test case for successful dealer update
    @Test
    public void testUpdateDealer_Success() {
        // Arrange: Mocking the behavior of dependencies
        when(dealerInfoRepository.findById(anyLong())).thenReturn(Optional.of(dealerInfoEntity));
        when(dealerInfoRepository.save(any(DealerInfoEntity.class))).thenReturn(dealerInfoEntity);

        // Act: Call the method
        DealerInfoEntity updatedDealer = loginService.updateDealer(1L, dealerInfoEntity);

        // Assert: Verify the updated dealer details
        assertNotNull(updatedDealer);
        assertEquals("dealerUser", updatedDealer.getUsername());
        assertEquals("dealer@example.com", updatedDealer.getEmail());
        assertEquals("123456789", updatedDealer.getPhoneNumber());
    }

    // Test case for when dealer is not found during update
    @Test
    public void testUpdateDealer_DealerNotFound() {
        // Arrange: Mocking the behavior of dependencies
        when(dealerInfoRepository.findById(anyLong())).thenReturn(Optional.empty());

        // Act & Assert: Expect an exception
        assertThrows(CustomException.class, () -> {
            loginService.updateDealer(1L, dealerInfoEntity);
        });
    }
}
