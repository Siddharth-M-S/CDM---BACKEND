package com.admin.repository;


import com.admin.entity.DealerInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DealerInfoRepository extends JpaRepository<DealerInfoEntity,Long> {



}
