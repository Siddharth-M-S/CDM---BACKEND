package com.admin.service.order_service;

import com.admin.entity.CartEntity;

import com.admin.entity.OrderEntity;

import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import java.util.Map;

import java.util.Optional;

public interface OrderServices {

    @Transactional

    CartEntity addCarToCart(Long dealerId, Long carId, Integer quantity);

    @Transactional

    OrderEntity addCarToExistingCart(Long dealerId, Long orderId, Long carId, Integer quantity);

    List<OrderEntity> getAllOrders();

    OrderEntity getOrderById(Long orderId);

    OrderEntity removeOrderItem(Long orderId, Long orderItemId);


    @Transactional

    OrderEntity placeOrder(Long dealerId, Long orderId,String address);

    @Transactional

    List<OrderEntity> getOrdersByDealer(Long dealerId);


    Optional<CartEntity> getCartItemsByDealer(Long dealerId);
    List<Map<String,Object>> getMaxCarSales();
    @Transactional
    Optional<CartEntity> removeCartItem(Long dealerId, Long cartItemId);
    boolean  softDeleteOrderById(Long id);
}

