package com.admin.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.MailException;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class EmailService {

    private final JavaMailSender emailSender;
    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    public EmailService(JavaMailSender emailSender) {
        this.emailSender = emailSender;
    }

    public boolean sendLoginCredentials(String dealerEmail, String username, String password, Long dealerId) {
        try {
            MimeMessage message = emailSender.createMimeMessage();

            MimeMessageHelper helper = new MimeMessageHelper(message, true); // 'true' indicates multipart email support

            helper.setTo(dealerEmail);
            helper.setSubject("Your Login Credentials");


            String htmlContent = "<html>" +
                    "<body>" +
                    "<h2>Dear Dealer,</h2>" +
                    "<p>Here are your login credentials for our platform <strong>Carquest</strong>:</p>" +
                    "<table>" +
                    "<tr><td><strong>DealerId:</strong></td><td>" + dealerId + "</td></tr>" +
                    "<tr><td><strong>Username:</strong></td><td>" + username + "</td></tr>" +
                    "<tr><td><strong>Password:</strong></td><td>" + password + "</td></tr>" +
                    "</table>" +
                    "<p><em>Please change your password after your first login.</em></p>" +
                    "<br>" +
                    "<p>Best Regards,<br/>Carquest</p>" +
                    "</body>" +
                    "</html>";

            // Set the HTML content
            helper.setText(htmlContent, true); // 'true' indicates HTML content

            // Send the email
            emailSender.send(message);
            logger.debug("Email successfully sent to: {}", dealerEmail);
            return true;

        } catch (MailException | MessagingException e) {
            logger.error("Error sending email to {}: {}", dealerEmail, e.getMessage(), e);
            return false;
        }
    }

    public void orderMessage(String dealerEmail, LocalDateTime orderDate, long orderId,String dealerName) {
        try {
            MimeMessage message = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(dealerEmail);
            helper.setSubject("Order Confirmation for Carquest");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");


            String htmlContent = "<html>" +
                    "<body>" +
                    "<h2>Dear "+ dealerName +",</h2>" +
                    "<p>Thank you for placing an order with <strong>Carquest</strong>.</p>" +
                    "<p>Your order is being processed and will be shipped soon. Please review the details below:</p>" +
                    "<table>" +
                    "<tr><td><strong>Order ID:</strong></td><td>O"+ orderId + "</td></tr>" +
                    "<tr><td><strong>Order Date:</strong></td><td>"+ orderDate.format(formatter) +"</td></tr>" +
                    "<tr><td><strong>Status:</strong></td><td>Processing</td></tr>" +
                    "</table>" +
                    "<br>" +
                    "<p>Best Regards,<br/>Carquest Team</p>" +
                    "</body>" +
                    "</html>";

            // Set the HTML content
            helper.setText(htmlContent, true);

            // Send the email
            emailSender.send(message);
            logger.debug("Order confirmation email successfully sent to: {}", dealerEmail);

        } catch (MailException | MessagingException e) {
            logger.error("Error sending order confirmation email to {}: {}", dealerEmail, e.getMessage(), e);
        }
    }




}
