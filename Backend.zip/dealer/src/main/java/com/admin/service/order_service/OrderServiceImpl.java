package com.admin.service.order_service;

import com.admin.entity.*;

import com.admin.exception.CustomException;
import com.admin.repository.*;

import com.admin.service.EmailService;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import java.time.LocalDateTime;
import java.util.*;

import static com.admin.service.LoginService.logger;

@Service

public class OrderServiceImpl implements OrderServices {

    private final CarRepository carRepo;

    private final OrdersRepository ordersRepository;

    private final OrderItemsRepository orderItemsRepository;

    private final DealerInfoRepository dealerInfoRepository;

    private final CartRepository cartRepository;

    private final CartItemsRepository cartItemsRepository;

    private final EmailService emailService;



    OrderServiceImpl(CarRepository carRepo, OrdersRepository ordersRepository, OrderItemsRepository orderItemsRepository, DealerInfoRepository dealerInfoRepository, CartRepository cartRepository, CartItemsRepository cartItemsRepository,EmailService emailService) {

        this.carRepo = carRepo;

        this.orderItemsRepository = orderItemsRepository;

        this.ordersRepository = ordersRepository;

        this.dealerInfoRepository = dealerInfoRepository;

        this.cartRepository = cartRepository;

        this.cartItemsRepository = cartItemsRepository;

        this.emailService=emailService;

    }

    @Transactional

    @Override

    public CartEntity addCarToCart(Long dealerId, Long carId, Integer quantity) {

        Car car = carRepo.findById(Math.toIntExact(carId)).orElseThrow(() -> new RuntimeException("Car not found"));

        DealerInfoEntity dealerInfoEntity = dealerInfoRepository.findById(dealerId).orElseThrow(() -> new RuntimeException("Dealer not found"));

        CartEntity cart = cartRepository.findByDealerInfoEntityId(dealerId).orElseGet(() -> {

            CartEntity newCart = new CartEntity();

            newCart.setDealerInfoEntity(dealerInfoEntity);

            newCart.setItems(new ArrayList<>()); // Initialize the items list

            return cartRepository.save(newCart);

        });

        CartItemEntity cartItem = new CartItemEntity();

        cartItem.setCar(car);

        cartItem.setQuantity(quantity);

        cartItem.setCart(cart);

        cartItemsRepository.save(cartItem);

        cart.getItems().add(cartItem);

        return cartRepository.save(cart);

    }

    @Override

    public OrderEntity addCarToExistingCart(Long dealerId, Long orderId, Long carId, Integer quantity) {

        return null;

    }


    @Override

    public List<OrderEntity> getAllOrders() {


        // Fetch all orders

        return ordersRepository.findAll();
    }

    @Override

    public OrderEntity getOrderById(Long orderId) {

        return null;

    }

    @Override

    public OrderEntity removeOrderItem(Long orderId, Long orderItemId) {

        return null;

    }

    @Transactional

    @Override

    public OrderEntity placeOrder(Long dealerId, Long cartId,String address) {

        CartEntity cart = cartRepository.findById(cartId).orElseThrow(() -> new RuntimeException("Cart not found"));

        if (!cart.getDealerInfoEntity().getId().equals(dealerId)) {

            throw new CustomException("Cart does not belong to the dealer");

        }

        OrderEntity order = new OrderEntity();

        order.setOrderDate(LocalDateTime.now());

        order.setTotalPrice(BigDecimal.ZERO);

        order.setItems(new ArrayList<>());

        order.setDealerInfoEntity(cart.getDealerInfoEntity());
        order.setAddresss(address);
        logger.debug("address{} ",order.getAddresss());

        for (CartItemEntity cartItem : cart.getItems()) {

            OrderItemEntity orderItem = new OrderItemEntity();

            orderItem.setCar(cartItem.getCar());

            orderItem.setQuantity(cartItem.getQuantity());

            orderItem.setOrder(order);

            orderItemsRepository.save(orderItem);

            order.getItems().add(orderItem);

        }

        updateTotalPrice(order);

        OrderEntity savedOrder = ordersRepository.save(order);

        cartRepository.delete(cart);





emailService.orderMessage(order.getDealerInfoEntity().getEmail(), order.getOrderDate(),order.getId(),order.getDealerInfoEntity().getUsername());


        return savedOrder;

    }

    private void updateTotalPrice(OrderEntity order) {

        BigDecimal totalPrice = order.getItems().stream()

                .map(item -> item.getCar().getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))

                .reduce(BigDecimal.ZERO, BigDecimal::add);

        order.setTotalPrice(totalPrice);

    }

    @Override

    public List<OrderEntity> getOrdersByDealer(Long dealerId) {

        return ordersRepository.findByDealerInfoEntityId(dealerId);

    }

    @Override
    public List<Map<String,Object>> getMaxCarSales() {
        return  ordersRepository.getMaxCarSales();}

    @Override
    public Optional<CartEntity> getCartItemsByDealer(Long dealerId) {
        // Fetch the cart for the given dealer ID.

        // Return the cart if it exists, otherwise return an empty Optional
        return cartRepository.findByDealerInfoEntityId(dealerId);
    }
    public boolean softDeleteOrderById(Long id) {

        try {

            Optional<OrderEntity> order = ordersRepository.findById(id);

            if (order.isPresent()) {

                OrderEntity existingOrder = order.get();

                existingOrder.setDeleted(true); // Mark the order as deleted

                ordersRepository.save(existingOrder);

                return true;

            }

            return false;

        } catch (Exception e) {


            throw new CustomException("Failed to mark the order as deleted.");

        }


    }
    @Transactional
    @Override
    public Optional<CartEntity> removeCartItem(Long dealerId, Long cartItemId) {
        // Log the received parameters for debugging
        logger.info("Attempting to remove cart item. Dealer ID: {}, CartItem ID: {}", dealerId, cartItemId);

        // Fetch the cart for the given dealer
        Optional<CartEntity> cartEntityOptional = cartRepository.findByDealerInfoEntityId(dealerId);
        if (!cartEntityOptional.isPresent()) {
            logger.error("Cart not found for dealer ID: {}", dealerId);
            return Optional.empty();  // Return empty if no cart is found
        }

        CartEntity cart = cartEntityOptional.get();

        // Log the cart details
        logger.info("Found cart for dealer ID: {}", dealerId);

        // Find the cart item by ID
        Optional<CartItemEntity> cartItemOptional = cartItemsRepository.findById(cartItemId);
        if (!cartItemOptional.isPresent()) {
            logger.error("Cart item with ID: {} not found in the cart.", cartItemId);
            return Optional.empty();  // Return empty if cart item is not found
        }

        CartItemEntity cartItem = cartItemOptional.get();

        // Log the cart item details
        logger.info("Found cart item with ID: {}", cartItemId);

        // Remove the cart item from the cart
        cart.getItems().remove(cartItem);

        // Log the removal of the item
        logger.info("Removing cart item with ID: {}", cartItemId);

        // Delete the cart item from the repository
        cartItemsRepository.delete(cartItem);

        // Save the updated cart
        cartRepository.save(cart);

        // Log the success
        logger.info("Successfully removed cart item with ID: {}", cartItemId);

        return Optional.of(cart);  // Return updated cart
    }






}
