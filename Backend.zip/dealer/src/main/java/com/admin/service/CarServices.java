package com.admin.service;

import com.admin.entity.Car;
import org.springframework.data.domain.Page;

import java.util.List;

public interface CarServices {
    List<Car> getAllCars();

    Car getCarById(int id);

    Page<Car> getAllCarsByPage(int page, int size);

    Car addCar(Car car);

    void deleteCar(int id);
    Car updateCar(int id, Car car);



    Car getCarByName(String carName);
}
